package com.ismchecklist.cargo

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

data class CheckItem(
    val phase: String,
    val code: String,
    val critical: Boolean,
    val question: String,
    val attention: List<String>,
    val actionIfNo: String,
    val reference: String
)

private val sampleItems = listOf(
    CheckItem(
        "PRE-LOADING", "PL-01", true,
        "Is the cargo hold clean, dry and suitable for loading?",
        listOf(
            "Check tank top, bulkheads and frames for previous cargo residue.",
            "Confirm there is no water, oil or other contamination.",
            "Check loose scale/rust and foreign material.",
            "Bilge wells, strainers and protective arrangements should be clean and ready."
        ),
        "Do not commence loading until the deficiency is corrected and the hold is re-inspected.",
        "ISM Code / SOLAS Ch. VI / Ship SMS / Cargo requirements"
    ),
    CheckItem(
        "PRE-LOADING", "PL-02", true,
        "Has cargo information been received and checked before loading?",
        listOf(
            "Verify cargo name, quantity, properties and stowage requirements.",
            "For solid bulk cargo, compare declaration with the applicable IMSBC schedule.",
            "For packaged dangerous goods, verify classification and documentation as applicable.",
            "Identify moisture, contamination, fire, chemical or shifting hazards."
        ),
        "Loading should not commence until the information required for safe carriage is available and verified.",
        "SOLAS Ch. VI / IMSBC Code / IMDG Code as applicable"
    ),
    CheckItem(
        "PRE-LOADING", "PL-03", true,
        "Has the loading plan and cargo distribution been checked?",
        listOf(
            "Check quantity planned for each hold.",
            "Verify loading sequence and terminal loading rate.",
            "Confirm ballast/deballast sequence.",
            "Check intermediate and final drafts, trim and list.",
            "Verify SF/BM, hold mass and tank-top/local loading limits."
        ),
        "Revise and approve the loading plan before loading starts.",
        "SOLAS VI/7 / BLU Code where applicable / Approved Loading Manual"
    ),
    CheckItem(
        "DURING LOADING", "DL-01", true,
        "Is actual cargo distribution following the approved loading plan?",
        listOf(
            "Compare actual loaded quantity with the planned quantity by hold/pour.",
            "Monitor port/starboard distribution and developing list.",
            "Monitor drafts and structural limits.",
            "Do not accept unplanned hold/pour changes without assessment."
        ),
        "Reduce rate or stop loading when necessary; reassess distribution, stability and structural limits.",
        "ISM Code / SOLAS Ch. VI / Loading Manual / BLU Code where applicable"
    ),
    CheckItem(
        "DURING LOADING", "DL-02", false,
        "Are weather and cargo conditions suitable to continue loading?",
        listOf(
            "Monitor rain and cargo wetting risk.",
            "Check wind effects on suspended or loose cargo.",
            "Watch for water accumulation in holds.",
            "Keep hatch-closing arrangements ready when required."
        ),
        "Request STOP LOADING when cargo, vessel or personnel safety may be affected.",
        "ISM Code / Ship SMS / Cargo-specific requirements"
    ),
    CheckItem(
        "POST-LOADING", "PO-01", true,
        "Are final draft, trim, list and stability satisfactory for departure?",
        listOf(
            "Record final forward and aft drafts.",
            "Check port/starboard draft difference and list.",
            "Update ballast, consumables and final displacement.",
            "Verify GM/stability and SF/BM within approved limits.",
            "Confirm the intended departure condition."
        ),
        "Do not treat the vessel as departure-ready until the final condition is safe and compliant.",
        "SOLAS / Approved Stability Information / Approved Loading Manual / Ship SMS"
    ),
    CheckItem(
        "POST-LOADING", "PO-02", true,
        "Is cargo stowage/securing completed and satisfactory?",
        listOf(
            "Check cargo shifting risk and void spaces.",
            "Verify lashings/dunnage where required.",
            "Check stack/tier limits and securing points.",
            "Confirm arrangements comply with the ship's approved Cargo Securing Manual when applicable."
        ),
        "Correct securing deficiencies before sailing.",
        "CSS Code / Cargo Securing Manual / Cargo-specific requirements"
    )
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface(modifier = Modifier.fillMaxSize()) { ChecklistApp() }
            }
        }
    }
}

@Composable
fun ChecklistApp() {
    var selectedPhase by remember { mutableStateOf("PRE-LOADING") }
    val phases = listOf("PRE-LOADING", "DURING LOADING", "POST-LOADING")
    val answers = remember { mutableStateMapOf<String, String>() }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
    ) {
        Text("ISM Checklist", style = MaterialTheme.typography.headlineMedium)
        Text("Cargo Loading Operations • V1 Prototype")
        Spacer(Modifier.height(12.dp))

        phases.forEach { phase ->
            Button(
                onClick = { selectedPhase = phase },
                modifier = Modifier.fillMaxWidth()
            ) { Text(phase) }
            Spacer(Modifier.height(6.dp))
        }

        Spacer(Modifier.height(8.dp))
        val phaseItems = sampleItems.filter { it.phase == selectedPhase }
        val done = phaseItems.count { answers.containsKey(it.code) }
        LinearProgressIndicator(
            progress = { if (phaseItems.isEmpty()) 0f else done.toFloat() / phaseItems.size },
            modifier = Modifier.fillMaxWidth()
        )
        Text("$done / ${phaseItems.size} completed")
        Spacer(Modifier.height(12.dp))

        phaseItems.forEach { item ->
            ChecklistCard(item, answers[item.code]) { answer ->
                answers[item.code] = answer
            }
            Spacer(Modifier.height(12.dp))
        }

        val openCritical = sampleItems.count { it.critical && answers[it.code] == "NO" }
        if (openCritical > 0) {
            Card(modifier = Modifier.fillMaxWidth()) {
                Text(
                    "$openCritical CRITICAL ITEM(S) OPEN — CHECKLIST CANNOT BE CLOSED",
                    modifier = Modifier.padding(16.dp),
                    style = MaterialTheme.typography.titleMedium
                )
            }
        }
        Spacer(Modifier.height(24.dp))
        Text(
            "Prototype note: regulatory references are guidance fields and must be verified against the vessel's current approved SMS, manuals, cargo documents and applicable code editions before operational use.",
            style = MaterialTheme.typography.bodySmall
        )
    }
}

@Composable
fun ChecklistCard(item: CheckItem, answer: String?, onAnswer: (String) -> Unit) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                "${item.code}${if (item.critical) " • CRITICAL" else ""}",
                style = MaterialTheme.typography.labelLarge
            )
            Spacer(Modifier.height(6.dp))
            Text(item.question, style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(10.dp))
            Text("Attention points", style = MaterialTheme.typography.labelLarge)
            item.attention.forEach { Text("• $it") }
            Spacer(Modifier.height(10.dp))
            Text("Action if NO", style = MaterialTheme.typography.labelLarge)
            Text(item.actionIfNo)
            Spacer(Modifier.height(10.dp))
            Text("Reference", style = MaterialTheme.typography.labelLarge)
            Text(item.reference)
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("YES", "NO", "N/A").forEach { option ->
                    if (answer == option) {
                        Button(onClick = { onAnswer(option) }) { Text(option) }
                    } else {
                        OutlinedButton(onClick = { onAnswer(option) }) { Text(option) }
                    }
                }
            }
        }
    }
}
