# ISM Checklist – Cargo Loading Operations (V1 Prototype)

Android/Kotlin + Jetpack Compose prototype.

## Included
- Pre-Loading
- During Loading
- Post-Loading
- YES / NO / N/A
- Attention Points
- Action if NO
- Regulation/reference field
- Critical NO warning
- Offline operation
- GitHub Actions workflow to build a debug APK in the cloud

## Important
This is a prototype. Regulatory references and checklist wording must be reviewed against:
- the vessel's current approved SMS/ISM procedures,
- approved Loading Manual / Stability Information,
- Cargo Securing Manual where applicable,
- current cargo declaration/information,
- and the currently applicable SOLAS / IMSBC / IMDG / BLU / CSS requirements.

It is not yet intended to replace an approved company checklist.

## Cloud build
Upload the project to GitHub, then run:
Actions → Build Android APK → Run workflow.
After completion, download the `ISM-Checklist-APK` artifact.
